package com.tech.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebcrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
